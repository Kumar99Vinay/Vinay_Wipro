package task2;

public class Shape {
	
	public void findArea() {
		
	}
}
