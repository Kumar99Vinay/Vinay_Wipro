package task2;

public class Rectangle extends Shape{
	
	double ar;
	public void findArea() {
		ar=4*8;
		System.out.println("Area of reactangle is : "+ar);
	}

	
}
