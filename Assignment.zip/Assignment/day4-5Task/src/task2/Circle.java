package task2;

public class Circle extends Shape {
	
	double a;
	public void findArea() {
		
		a=3.14*5*5;
		System.out.println("Area of circle is : "+a);
	}
	
}
