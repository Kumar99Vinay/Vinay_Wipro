package task2;


public class Test {

	public static void main(String[] args) {
		Shape s;
		s = new Circle();
		s.findArea();
		s=new Rectangle();
		s.findArea();

	}

}
