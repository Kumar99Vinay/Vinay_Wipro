package task4;

public class DivsibleByZero {

	public static void main(String[] args) {
		try {
			// Attempt to divide by zero
			int result = divideByZero(10, 0);
			System.out.println("Result: " + result);
		} catch (ArithmeticException e) {
			// Custom error message
			System.err.println("Not divisible by Zero");
		}

	}

	public static int divideByZero(int dividend, int divisor) {
		// Attempt division
		return dividend / divisor;
	}

}
