package task4;

import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Queue;

public class CustomQueue<T> {

	private Queue<T> queue;

	public CustomQueue() {
		queue = new LinkedList<>();
	}

	public void enqueue(T item) {
		queue.offer(item);
	}

	public T dequeue() {
		if (isEmpty()) {
			throw new NoSuchElementException("Queue is empty");
		}
		return queue.poll();
	}

	public T peek() {
		if (isEmpty()) {
			throw new NoSuchElementException("Queue is empty");
		}
		return queue.peek();
	}

	public boolean isEmpty() {
		return queue.isEmpty();
	}

	public static void main(String[] args) {
		
		CustomQueue<String> stringQueue = new CustomQueue<>();

		stringQueue.enqueue("Vinay");
		stringQueue.enqueue("Kumar");

		// Dequeue and display strings
		while (!stringQueue.isEmpty()) {
			System.out.println("Dequeued: " + stringQueue.dequeue());
		}

		// Create a CustomQueue to handle integers
		CustomQueue<Integer> integerQueue = new CustomQueue<>();

		// Enqueue integers
		integerQueue.enqueue(1);
		integerQueue.enqueue(2);
		integerQueue.enqueue(3);

		// Dequeue and display integers
		while (!integerQueue.isEmpty()) {
			System.out.println("Dequeued: " + integerQueue.dequeue());
		}
	}

}
