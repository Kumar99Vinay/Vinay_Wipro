package task4;

public class Main {
	
	 public static void main(String[] args) {
	        CustomStack<Integer> stack = new CustomStack<>();

	        stack.push(1);
	        stack.push(2);
	        stack.push(3);
	        stack.push(4);
	        stack.push(5);

	       
	        while (!stack.isEmpty()) {
	            System.out.println("Popped: " + stack.pop());
	        }
	    }

}
