package com.math.operations;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		double a=s.nextDouble();
		double b=s.nextDouble();
		System.out.println("Addition: " + Addition.add(a, b));
		System.out.println("Subtraction: " + Subtraction.sub(a, b));
		System.out.println("Multiplication: " + Multiplication.mult(a, b));
		System.out.println("Division is : "+Division.div(a, b));

	}

}
