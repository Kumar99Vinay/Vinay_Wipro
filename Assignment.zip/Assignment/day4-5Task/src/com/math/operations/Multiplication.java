package com.math.operations;

public class Multiplication {
	
	public static double mult(double a,double b) {
		return a*b;
	}
	

}
