package com.math.operations;

public class Subtraction {
	
	public static double sub(double a, double b) {
		return a - b;
	}


}
