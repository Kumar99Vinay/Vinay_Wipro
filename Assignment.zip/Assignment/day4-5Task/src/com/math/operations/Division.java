package com.math.operations;

public class Division {
	
	public static double div(double a,double b) {
		return a/b;
	}

}
