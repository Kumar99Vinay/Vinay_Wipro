package com.math.operations;

public class Addition {

	public static double add(double a, double b) {
		return a + b;
	}

}
