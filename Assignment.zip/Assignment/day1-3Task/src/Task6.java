import java.util.Scanner;

public class Task6 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter array size");
		int n = s.nextInt();
		int[] arr = new int[n];
		for (int i = 0; i < arr.length; i++) {
			System.out.println("Enter array element : " + (i + 1));
			arr[i] = s.nextInt();
		}
		int sum=sumArr(arr);
		System.out.println("The sum is : "+sum);

	}

	public static int sumArr (int[] arr) {
		return sumArrayHelper(arr, arr.length - 1);
	}

	private static int sumArrayHelper(int[] arr, int index) {

		if (index < 0) {
			return 0;
		}

		return arr[index] + sumArrayHelper(arr, index - 1);
	}

}
