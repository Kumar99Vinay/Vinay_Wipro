import java.util.Arrays;
import java.util.Scanner;

public class Task5 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter array size");
		int n = s.nextInt();
		System.out.println("Enter a target element");
		int target=s.nextInt();
		int[] arr = new int[n];
		for (int i = 0; i < arr.length; i++) {
			System.out.println("Enter array element : " + (i + 1));
			arr[i] = s.nextInt();
		}
	
		findSum(arr,target);

	}
	
	private static void findSum(int[] arr,int target) {
		 for(int i=0;i<arr.length;i++) {
			 for(int j=i+1;j<arr.length;j++) {
				 if(arr[i]+arr[j]==target) {
					 System.out.println("found");
					 System.exit(0);
				 }
			 }
		 }
		 System.out.println("Not found");
		
	}

}
