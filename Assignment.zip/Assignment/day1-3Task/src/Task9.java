import java.util.Scanner;

public class Task9 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);																																							
		String s1=s.nextLine();
		String s2=s.nextLine();
		String str3=s1.concat(s2);
		System.out.println(str3);
		StringBuilder reversed = new StringBuilder(str3).reverse();
		String str4=reversed.toString();
		System.out.println(str4);
		int length=str4.length();
		int sub=(str4.length()/2)/2;
		System.out.println(str4.substring(sub,str4.length()-((str4.length())/2)));
		
		

	}

}
