import java.util.Arrays;
import java.util.Scanner;

public class Task4 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter array size");
		int n = s.nextInt();
		int[] arr = new int[n];
		for (int i = 0; i < arr.length; i++) {
			System.out.println("Enter array element : " + (i + 1));
			arr[i] = s.nextInt();
		}
		Arrays.sort(arr);
		reverse(arr);

	}
	
	private static void reverse(int[] arr) {
		 for(int i=arr.length-1;i>=0;i--) {
			 System.out.println(arr[i]);
		 }
		
	}


}
