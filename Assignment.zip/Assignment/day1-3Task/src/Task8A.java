import java.util.Arrays;
import java.util.Scanner;

public class Task8A {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter array size");
		int n = s.nextInt();
		System.out.println("Enter a start index");
		int start = s.nextInt();
		System.out.println("Enter a end index");
		int end = s.nextInt();
		int[] arr = new int[n];
		for (int i = 0; i < arr.length; i++) {
			System.out.println("Enter array element : " + (i + 1));
			arr[i] = s.nextInt();
		}
		int[] slicedArray = sliceArray(arr, start, end);
		 System.out.println("Original array: " + Arrays.toString(arr));
	        System.out.println("Sliced array from index " + start + " to " + end + ": " + Arrays.toString(slicedArray));

	}

	private static int[] sliceArray(int[] arr, int start, int end) {

		if (start < 0 || end >= arr.length || start > end) {
			System.out.println("Invalid input");
			System.exit(0);
		}

		int length = end - start + 1;
		int[] slicedArray = new int[length];

		for (int i = 0; i < length; i++) {
			slicedArray[i] = arr[start + i];
		}

		return slicedArray;

	}

}
