import java.util.Scanner;

public class Task7B {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter array size");
		int n = s.nextInt();
		System.out.println("Enter a target element");
		int target=s.nextInt();
		int[] arr = new int[n];
		for (int i = 0; i < arr.length; i++) {
			System.out.println("Enter array element : " + (i + 1));
			arr[i] = s.nextInt();
		}
		
		System.out.println(linearSearch(arr,target));

	}

	private static int linearSearch(int[] arr, int target) {
		
		for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i; 
            }
        }
        return -1;
	}

}
