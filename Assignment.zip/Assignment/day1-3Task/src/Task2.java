
public class Task2 {

	public static void main(String[] args) {
		
		int n=Integer.parseInt(args[0]);
		double x=Double.parseDouble(args[0]);
		double y=Double.parseDouble(args[0]);
		double result=0;
		switch (n) {
		case 1:
			result=x+y;
			break;
			
		case 2:
			result=x-y;
			break;
			
		case 3:
			result=x*y;
			break;
			
		case 4:
			result=x/y;
			break;

		default:
			System.out.println("Invalid output");
			break;
		}
		

	}

}
