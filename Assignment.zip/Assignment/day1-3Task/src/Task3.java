import java.util.Scanner;

public class Task3 {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int temp=0;
		for(int i=2;i<=n/2;i++) {
			if(n%i==0) {
				temp++;
				System.out.println("Not a prime number");
				System.exit(0);
			}
		}
		if(temp == 0) {
			System.out.println("it is a prime number");
		}

	}

}
